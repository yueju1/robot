# PM Client

Bibliothek für die Kommunikation zwischen PM-Zelle und anderen Rechnern/Programmen.

Siehe `PMClient::Client` als Startpunkt.
