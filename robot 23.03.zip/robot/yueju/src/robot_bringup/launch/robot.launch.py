from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    
    ld = LaunchDescription()

    Transform1_Node = Node(
        package="lab",
        executable="teil_zwei",
        parameters=[
        {'frame_id':'Camera_Calibration'},
        {'child_frame_id':'gripper'},
        {'translation.x':0.0},
        {'translation.y':0.0},
        {'translation.z':0.0},
        {'rotation.x':0.0},
        {'rotation.y':0.0},
        {'rotation.z':0.0},
        {'rotation.w':0.1}
        ]
    )

    MyListener_Node = Node(
        package="listener",
        executable="listener_1",
        parameters=[{"components to be calibrated":"gripper"}]
    )


    ld.add_action(Transform1_Node)
    ld.add_action(MyListener_Node)


    return ld
