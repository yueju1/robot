import rclpy
from rclpy.node import Node
from tf2_ros.buffer import Buffer
from tf2_ros.transform_listener import TransformListener
from rclpy.time import Time

class MyListener(Node):
    def __init__(self):
        super().__init__("system_listener")
        #下面这个self可以不要把
        self.buffer1=Buffer()

        listener1=TransformListener(self.buffer1,self)

        self.timer1=self.create_timer(1.2,self.looking)

    def looking(self):
        if self.buffer1.can_transform("base_link","new",Time()):
            bu=self.buffer1.lookup_transform("base_link","new",Time())
            self.get_logger().info("the result ist:father:%s,son:%s,corodinate%f,%f,%f,%f,%f,%f,%f"
                               %(bu.header.frame_id,
                                 bu.child_frame_id,
                                 bu.transform.translation.x,
                                 bu.transform.translation.y,
                                 bu.transform.translation.z,
                                 bu.transform.rotation.x,
                                 bu.transform.rotation.y,
                                 bu.transform.rotation.z,
                                 bu.transform.rotation.w)
                               )
    
            
        else:
            self.get_logger().info("This transform does not exist")



  



def main():
    
    rclpy.init()
    rclpy.spin(MyListener())
    rclpy.shutdown()


if __name__ == '__main__':
    main()