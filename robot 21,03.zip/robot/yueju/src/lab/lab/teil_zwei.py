import rclpy
from rclpy.node import Node
from tf2_ros.static_transform_broadcaster import StaticTransformBroadcaster
from geometry_msgs.msg import TransformStamped

class Transform1(Node):
    def __init__(self):
        super().__init__("Camera_System_from_base_link")
        
        self.declare_parameters('',
                                [('frame_id','Camera_Calibration'),('child_frame_id','new gripper'),
                                ('translation.x',0),('translation.y',0),('translation.z',2),
                                ('rotation.x',0),('rotation.y',0),('rotation.z',0),('rotation.w',1)])

        #self.parameter=self.get_parameters(['frame_id','child_frame_id',
         #                                  'translation.x','translation.y','translation.z',
          #                                 'rotation.x','rotation.y','rotation.z','rotation.w'])

        #下面这个self可以不要把
        self.broadcaster1=StaticTransformBroadcaster(self)

        ts1=TransformStamped()
        
        ts1.header.stamp=self.get_clock().now().to_msg()
        ts1.header.frame_id='self.parameter[0]'
        ts1.child_frame_id='self.parameter[1]'

        ts1.transform.translation.x=0.0
        ts1.transform.translation.y=0.0
        ts1.transform.translation.z=0.0

        ts1.transform.rotation.x=0.0
        ts1.transform.rotation.y=0.0
        ts1.transform.rotation.z=0.0
        ts1.transform.rotation.w=0.0

        self.broadcaster1.sendTransform(ts1)


  



def main():
    rclpy.init()
    rclpy.spin(Transform1())
    
    rclpy.shutdown()


if __name__ == '__main__':
    main()
