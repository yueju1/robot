import rclpy
from rclpy.node import Node
from tf2_ros.static_transform_broadcaster import StaticTransformBroadcaster
from geometry_msgs.msg import TransformStamped
#yong numpy!!!???
import xml.dom
import transforms3d
import math
from decimal import *



#         （gravity off？）
# class Transform1(Node):
#     def __init__(self):
#         super().__init__("relative_position_gripper_to_upper_camera")
        #下面这个self可以不要把
#         self.broadcaster1=StaticTransformBroadcaster(self)

#         ts1=TransformStamped()
        
#         ts1.header.stamp=self.get_clock().now().to_msg()
#         ts1.header.frame_id="Z_Axis"
#         ts1.child_frame_id="Gripper"

#         ts1.transform.translation.x=0.0...chao yi xia + numpy
#         ts1.transform.translation.y=
#         ts1.transform.translation.z=

#         ts1.transform.rotation.x=
#         ts1.transform.rotation.y=
#         ts1.transform.rotation.z=
#         ts1.transform.rotation.w=

#         self.broadcaster1.sendTransform(ts1)


# Pose= transforms3d.euler.quat2euler([1, 123, 546, 234])
# print(Pose)  
a=0.07950000000002435
c=0.0075002334          #最多17位小数
b=[]
d=[]
e=[]
#t=(i for i in )
print(getcontext())
#getcontext().prec=17
#getcontext().rounding=ROUND_DOWN

# s='%.17g' %a
# print(s)
# m="%.19s"%s
# print(float(m))
# print(str(a).format())
# print(len(str(a))-2)
# print(len(str(c))-2)
# if a//10==0:
#      a=a*10**(len(str(a))-1)
# decimal.getcontext().prec=17
# print(decimal.Decimal.from_float(0.07750000000002335))
# z=decimal.Decimal.from_float(0.07750000000002335)

# print(math.floor(a*10**(len(str(a))-2)))
# print(math.floor(a*10**(len(str(a))-2))/(10**(len(str(a))-2)))
print(int(a))
# d=0.07750000000002335
# print(d)
#Decimal.__format__             看看看看看看看
print(getcontext())
#getcontext().prec=18
print('%.18f'%(Decimal('0.07750000000002335')+2))
print(Decimal('0.07750000000002335')+2)
print(str(Decimal('0.07750000000002338')+Decimal('0.07750000000002337')))
print(0.07750000000002334)
print(1.01234567856)
print(0.068500020970795)
#getcontext().prec=17
print(Decimal('0.0775000000002358')+Decimal('0.077500000000027'))
print(123)
print(Decimal(2.07750000000027)  +Decimal(2.07750000000028))
print(0.07750000000027+0.07750000000028)
print(1.077500000000028)#用这个！！Decimal(input)+Decimal(<origin xyz="0.0795000000000243)  asd.py word说input
print(len(str(0.07950000000002435)))
print(0.07950000000000249+0.07950000000000246)

print('%.19f'%(0.0795000000000249+0.0795000000000242))

print(type('%.19f'%(0.0795000000000249+0.0795000000000242)))
print('%.19f'%(10.0795000000000249+10.0795000000000242))
# getcontext().prec=3
getcontext().rounding=ROUND_DOWN
print(Decimal('0.23')+Decimal('0.23'))
    
# print(float(d))
# print(a)
print(Decimal('0.07950000000002435')+Decimal('0.23156418'))
print(Decimal(0.23156418))
print('%.53f'%(0.23156418))
# print(0.07750000000002335)
print(Decimal('0.125135362164125642145625'))
print(len('0.0795000000000243'))
# print(math.floor(c*10**(len(str(c))-2)))
# print(math.floor(c*10**(len(str(c))-2))/(10**(len(str(c))-2)))
# for i in str(a) :
#         b.append(i)
# print(b)
# for i in str(c):
#         d.append(i)
# while len(d) < len(b):
        
#           d.append('0')
# while len(b) < len(d):
        
#           b.append('0')
# print(b)
# for i in range(2,len(d)):
#        e.append(int(d[i])+int(b[i]))
        # if e[]
# print(a//10)
# print(len(str(a)))
# print (str(a).count(str(a)))
# print(float(a))    
# print(e)
# print(b)
# print(d)
# print(len(d)-len(b))


# math.floor(a)








# def main():
#     rclpy.init()
#     rclpy.spin(Transform1())
    
#     rclpy.shutdown()


# if __name__ == '__main__':
#     main()
