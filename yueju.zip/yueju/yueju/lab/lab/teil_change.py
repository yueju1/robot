import rclpy
from rclpy.node import Node
#import xml.etree.ElementTree as ET
import lxml.etree as ET
from decimal import *
#getcontext().rounding=ROUND_DOWN


class Change(Node):
     def __init__(self):
        super().__init__("Change")
        
        
                #别这么搞，最后要在terminal输入paramater然后执行，这样要一直启动urdf，会和他有冲突吗

        
        
        a=Decimal(input("Translation increment on x: "))  #这个名字符合语法吗，你给一个
        b=Decimal(input("Translation increment on y: "))
        c=Decimal(input("Translation increment on z: "))
        d=Decimal(input("Rotation increment on x: "))  #这俩可以省略，以及下面程序里的修改
        e=Decimal(input("Rotation increment on y: "))  
        f=Decimal(input("Rotation increment on z: "))  #顺时针还是逆时针的
        print(getcontext())
        parameter=[a,b,c,d,e,f]
        #得到的数据类型是啥样子的
        # self.declare_parameters('',
        #                         [#('frame_id', 'Camera_Top_View'),
        #                          #('child_frame_id', 'New_Gripper'),
        #                          ('name','Gripper'),
        #                          ('tx', 0.0),#+Increment[0]),
        #                          ('ty', 0.0),#+Increment[1]),
        #                          ('tz', 0.0),#+Increment[2]),
        #                          ('rx', 0.0),#+Increment[3]),
        #                          ('ry', 0.0),#+Increment[4]),
        #                          ('rz', 500.0)                     # jiaodu  pai?
        #                          ])
#0.0+Increment[5]
        # parameter = self.get_parameters([#'frame_id', 'child_frame_id',
        #                                     'name',
        #                                       'tx', 'ty', 'tz',
        #                                       'rx', 'ry', 'rz'])
        
       # self.paramater=[1,2,3,4,5,6,4,5]
     #def sda(self):
    #看listener  没有回调函数不执行阿
        
        #if parameter[0].value == 'Gripper':
        tree = ET.parse(
            '/home/pmlab/match_pm_robot/pm_robot_description/urdf/pm_robot.urdf')
        root = tree.getroot()
            
            #要修改的小数位数不一样，所以能另一个if吗：if。。。else 单独加0.096
        for i in root.iter('joint'):
            # if m == 'Gripper':
                if  m == 'Gripper' and i.attrib['name'] == "Gripper_Rot_Plate_Joint":
                                            #这个18大吗，因为多余的位数会浮动 不准确,
                                            # 所以得到的增量数据是准确的16位小数吗,
                                            #有的元件不是16位小数
                    i.find('origin').set('xyz', '%s %s %s'      #aus urdf  aufrae
                                         %(parameter[0]+Decimal('0.0795000000000243'),
                                            parameter[1]+Decimal('0.068500020970708'),
                                            parameter[2]+Decimal('0.096')-Decimal('0.233999999999991'))
                                        )# 弧度 但是得到的增量向量是弧度吗？
                                                            #增量向量是几位数的   
                    i.find('origin').set('rpy', '%s %s %s'%(parameter[3]+Decimal('0'),
                                                        parameter[4]+Decimal('0'),
                                                        parameter[5]+Decimal('0')
                                                        ))
            # elif m in Name[1:]:
                if m in Name[1:] and i.attrib['name'] == m+"_Joint":
                    i.find('origin').set('xyz', '%s %s %s'
                                             %(parameter[0]+Decimal('0.0795000000000243'),
                                                parameter[1]+Decimal('0.068500020970708'),
                                                #这个数据长度是十几，urdf里原来的只有几位小数，要哪个
                                                parameter[2]-Decimal('0.233999999999991')
                                            ))
                        
                                                  
                 #角度除以360?                                          
                    i.find('origin').set('rpy', '%s %s %s'%(parameter[3]+Decimal('0'),
                                                        parameter[4]+Decimal('0'),
                                                        parameter[5]+Decimal('0')
                                                        ))
        tree.write('asd1')
             
                #先改gripprt plate joint  然后整个的frame
                #print(i.find('origin').get('xyz'))
        with open('asd1',
       #(  )         
                          'r+', encoding='utf-8') as file:
                        co = file.read()

                        file.seek(0, 0)
                        file.write('<?xml version="1.0" encoding="utf-8"?>\n'+co)
                        print(co.find('<ro'))

        with open('asd1', 'r+',encoding='utf-8') as file1:

                        new = file1.read()
                    # print(new.find('<ro'))
                        file1.seek(new.find('<ro'))
                        file1.write('\n<robot name="pm_robot">') #中间少一行这样行吗，不行就。。+read([..])
             
        # elif parameter[0].value in Name:
        #     print(parameter[0].value)
        #     tree = ET.parse(
        #     '/home/pmlab/match_pm_robot/pm_robot_description/urdf/pm_robot.urdf')
        #     root = tree.getroot()
        #     for x in root.iter('joint'):
                
                
        #         if x.attrib['name'] == parameter[0].value+"_Joint":
        #             print(x)                      
        #             x.find('origin').set('xyz', '%.18f %.18f %.18f'%(parameter[1].value+0.0795000000000243,
        #                                                 parameter[2].value+0.068500020970708,
        #                                                 parameter[3].value-0.233999999999991
        #                                                 ))  
                    
        #             x.find('origin').set('rpy', '%f %f %f'%(parameter[4].value,
        #                                                 parameter[5].value,
        #                                                 parameter[6].value
        #                                                 ))
        #             tree.write('/home/pmlab/yueju/asd1.urdf')
        #             print(234)
        #             print(x.find('origin').get('xyz'))
        #             with open('/home/pmlab/yueju/asd1.urdf',
        #                   'r+', encoding='utf-8') as file:
        #                 co = file.read()

        #                 file.seek(0, 0)
        #                 file.write('<?xml version="1.0" encoding="utf-8"?>\n'+co)
        #                 print(co.find('<ro'))

        #             with open('/home/pmlab/yueju/asd1.urdf', 'r+') as file1:

        #                 new = file1.read()
                    
        #                 file1.seek(new.find('<ro'))
        #                 file1.write('\n<robot name="pm_robot">')
        #             print(123)
        
        
                # else:
                #     self.get_logger().info('wrong')
                    

    
                    
                   # new= file.readlines()
                   # print(new)
                    #print(co)
                    #for line in co:
                    # if '<robot' in co:
                    #      print(co.find('<ro'))
                    #      print(123)
                         # file.seek(file.tell())
                         # file.read()
                         # print(file.tell())
                         #file.seek(file.tell())
                         #file.write('\n')                       

def main():
   
       
        rclpy.init()
        rclpy.spin(Change())
        rclpy.shutdown()
    
    
        

if __name__ == '__main__':
    Name = ['Gripper','1K_Dispenser','2K_Dispenser']
    m= input('Please enter the name of the component to be calibrated: ')
    if m in Name:
        main()
    else: 
        rclpy.node.get_logger('Error').info('Invalid name. Please enter one of the following names:\n'
                                             'Gripper'+','+'1K_Dispenser'+','+'2K_Dispenser')

""" 
kl=file.readlines()
lie = '    <color rgba="0.792156862745098 0.819607843137255 0.933333333333333 1" />\n'
for line in kl:
   if line==lie: 
      print(lie)  
        
 """
