import rclpy
from rclpy.node import Node
from tf2_ros.static_transform_broadcaster import StaticTransformBroadcaster
from geometry_msgs.msg import TransformStamped
# import tf_transformations
import transforms3d


class Transform1(Node):
    def __init__(self):
        super().__init__('StaticBroadcaster_Gripper_from_Camera_Top_View')

        self.declare_parameters('',
                                [('frame_id', 'Camera_Top_View'),
                                 ('child_frame_id', 'New_Gripper'),
                                 ('translation.x', 0.0795000000000243),
                                 ('translation.y', 0.068500020970708),
                                 ('translation.z', -0.233999999999991),
                                 ('rotation.x', 0.0),
                                 ('rotation.y', 0.0),
                                 ('rotation.z', 0.0)])

        self.parameter = self.get_parameters(['frame_id', 'child_frame_id',
                                              'translation.x', 'translation.y', 'translation.z',
                                              'rotation.x', 'rotation.y', 'rotation.z'])

        # 下面这个self可以不要把
        self.broadcaster1 = StaticTransformBroadcaster(self)

        ts1 = TransformStamped()

        ts1.header.stamp = self.get_clock().now().to_msg()
        ts1.header.frame_id = self.parameter[0].value
        ts1.child_frame_id = self.parameter[1].value

        ts1.transform.translation.x = self.parameter[2].value
        ts1.transform.translation.y = self.parameter[3].value
        ts1.transform.translation.z = self.parameter[4].value

        rotation = transforms3d.euler.euler2quat(
            # jia kuohao tuple   kanfanhuizhi  kanyixia  siyuanshu de dingyi
            self.parameter[5].value,
            self.parameter[6].value,
            self.parameter[7].value)

        ts1.transform.rotation.x = rotation[1]
        ts1.transform.rotation.y = rotation[2]
        ts1.transform.rotation.z = rotation[3]
        ts1.transform.rotation.w = rotation[0]

        self.broadcaster1.sendTransform(ts1)


def main():
    rclpy.init()
    rclpy.spin(Transform1())
    
    rclpy.shutdown()


if __name__ == '__main__':
    main()
