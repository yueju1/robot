from decimal import *
# s=input("sad")
# print(s)
# d=0.07750000000002335
# print(d)
#print(bin(0.1590000000000495))
print(Decimal(0.23156418))