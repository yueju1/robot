import rclpy
from rclpy.node import Node
from tf2_ros.buffer import Buffer
from tf2_ros.transform_listener import TransformListener
from rclpy.time import Time
import transforms3d
# import xml.etree.ElementTree as ET
import lxml.etree as ET


class MyListener(Node):
    def __init__(self):
        super().__init__("system_listener")

        self.declare_parameter(
            "components to be calibrated", 'New_Gripper')

        self.parameter = self.get_parameter("components to be calibrated")

        # 下面这个self可以不要把
        self.buffer1 = Buffer()

        listener1 = TransformListener(self.buffer1, self)

        self.timer1 = self.create_timer(1.2, self.looking)

    def looking(self):
        if self.buffer1.can_transform('Z_Axis', str(self.parameter.value), Time()):
            self.bu = self.buffer1.lookup_transform(
                'Z_Axis', str(self.parameter.value), Time())
            self.get_logger().info("the result is:father:%s,son:%s,corodinate:%f,%f,%f,%f,%f,%f,%f"
                                   % (self.bu.header.frame_id,  # float jiweishu
                                      self.bu.child_frame_id,
                                      self.bu.transform.translation.x,
                                      self.bu.transform.translation.y,
                                      self.bu.transform.translation.z,
                                      self.bu.transform.rotation.x,
                                      self.bu.transform.rotation.y,
                                      self.bu.transform.rotation.z,
                                      self.bu.transform.rotation.w)
                                   )
            
            self.data = transforms3d.euler.quat2euler([self.bu.transform.rotation.w,
                                                       self.bu.transform.rotation.x,
                                                       self.bu.transform.rotation.y,
                                                       self.bu.transform.rotation.z
                
            ])
       
             #别跟在回调函数里面
            tree = ET.parse(
            '/home/yueju/match_pm_robot/pm_robot_description/urdf/pm_robot.urdf')
            root = tree.getroot()
            
            for i in root.iter('joint'):
                if i.attrib['name'] == "Gripper_Joint":
                    i.find('origin').set('xyz', '%f %f %f'
                                         %(self.bu.transform.translation.x,
                                           self.bu.transform.translation.y,
                                           self.bu.transform.translation.z,
                        
                    ))
                    i.find('origin').set('rpy', '%f %f %f'
                                         %(self.data[0],self.data[1],self.data[2]))
                    
                    tree.write('asd1.urdf')

                    print(i.find('origin').get('xyz'))
                    with open('asd1.urdf',
                          'r+', encoding='utf-8') as file:
                        co = file.read()

                        file.seek(0, 0)
                        file.write('<?xml version="1.0" encoding="utf-8"?>\n'+co)
                        print(co.find('<ro'))

                    with open('asd1.urdf', 'r+') as file1:

                        new = file1.read()

                        file1.seek(new.find('<ro'))
                        file1.write('\n<robot name="pm_robot">') #中间少一行这样行吗，不行就。。+read([..])
            print(12345)      

        else:
            self.get_logger().info("This transform does not exist")
            
 
    # def adjust(self):
    #         #别跟在回调函数里面
    #         tree = ET.parse(
    #         '/home/yueju/match_pm_robot/pm_robot_description/urdf/pm_robot.urdf')
    #         root = tree.getroot()
            
    #         for i in root.iter('joint'):
    #             if i.attrib['name'] == "Gripper_Joint":
    #                 i.find('origin').set('xyz', '%f %f %f'
    #                                      %(self.bu.transform.translation.x,
    #                                        self.bu.transform.translation.y,
    #                                        self.bu.transform.translation.z,
                        
    #                 ))
    #                 i.find('origin').set('rpy', '%f %f %f'
    #                                      %(self.data[0],self.data[1],self.data[2]))
                    
    #                 tree.write('asd1.urdf')

    #                 print(i.find('origin').get('xyz'))
    #                 with open('asd1.urdf',
    #                       'r+', encoding='utf-8') as file:
    #                     co = file.read()

    #                     file.seek(0, 0)
    #                     file.write('<?xml version="1.0" encoding="utf-8"?>\n'+co)
    #                     print(co.find('<ro'))

    #                 with open('asd1.urdf', 'r+') as file1:

    #                     new = file1.read()

    #                     file1.seek(new.find('<ro'))
    #                     file1.write('\n<robot name="pm_robot">') #中间少一行这样行吗，不行就。。+read([..])
    #         print(12345)

 
            
            
        

        # kaolv exception


def main():
    
    rclpy.init()
    rclpy.spin(MyListener())
    rclpy.shutdown()


if __name__ == '__main__':
    main()