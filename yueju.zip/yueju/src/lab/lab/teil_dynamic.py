import rclpy
from rclpy.node import Node
from tf2_ros import TransformBroadcaster
from geometry_msgs.msg import TransformStamped
from tf2_msgs.msg import TFMessage





class Dynamictransform(Node):
    def __init__(self):
        super().__init__("Camera_Calibration_from_Camera_System")
        self.dy_broadcaster=TransformBroadcaster(self)

        sub=self.create_subscription(TFMessage,"/tf",self.do_transform,10)
    
    def do_transform(self,pose):
        ts=TransformStamped()
        
        
        ts.header.stamp=self.get_clock().now().to_msg()

        ts.header.frame_id=pose.transforms[0].header.frame_id
        ts.child_frame_id=pose.transforms[0].child_frame_id   #这两行改一下！！！用 pose里的。

        ts.transform.translation.x=pose.transforms[0].transform.translation.x
        ts.transform.translation.y=pose.transforms[0].transform.translation.y
        ts.transform.translation.z=pose.transforms[0].transform.translation.z
      
        ts.transform.rotation.x=pose.transforms[0].transform.rotation.x
        ts.transform.rotation.y=pose.transforms[0].transform.rotation.y
        ts.transform.rotation.z=pose.transforms[0].transform.rotation.z
        ts.transform.rotation.w=pose.transforms[0].transform.rotation.w

        

        self.dy_broadcaster.sendTransform(ts)
        self.get_logger().info("hahaha")


def main():
    rclpy.init()
    rclpy.spin(Dynamictransform())
    
    rclpy.shutdown()


if __name__ == '__main__':
    main()