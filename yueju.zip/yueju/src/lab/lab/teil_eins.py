import rclpy
from rclpy.node import Node
from tf2_ros.static_transform_broadcaster import StaticTransformBroadcaster
from geometry_msgs.msg import TransformStamped

class Transform1(Node):
    def __init__(self):
        super().__init__("Camera_System_from_base_link")
        self.broadcaster1=StaticTransformBroadcaster(self)

        ts1=TransformStamped()
        
        ts1.header.stamp=self.get_clock().now().to_msg()
        ts1.header.frame_id="base_link"
        ts1.child_frame_id="Camera_System"

        ts1.transform.translation.x=0.6025
        ts1.transform.translation.y=0.5075
        ts1.transform.translation.z=0.1

        ts1.transform.rotation.x=0.0
        ts1.transform.rotation.y=0.0
        ts1.transform.rotation.z=0.0
        ts1.transform.rotation.w=1.0

        self.broadcaster1.sendTransform(ts1)


  



def main():
    rclpy.init()
    rclpy.spin(Transform1())
    
    rclpy.shutdown()


if __name__ == '__main__':
    main()
