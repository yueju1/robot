from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():

    ld = LaunchDescription()

    paramater = ''

    Pose = [0.0,  # vektor mingzi
            0.0,
            0.0,
            0.0,  # jiaodu  pai?
            0.0,
            0.0]

    Transform1_Node = Node(
        package="lab",
        executable="teil_zwei",
        parameters=[
            {'frame_id': 'Camera_Top_View'},
            # mingzi xiangtong you jige a kan rviz   launch mehr systematisch  broadcaster he listener shi gudingde suoyi bu fei naoxibao
            # gen fuza de haishi broadcaster he listener hao
            {'child_frame_id': paramater},
            # weishu buziyang  gen %f lianxi
            {'translation.x': 0.0795000000000243+Pose[0]},
            {'translation.z': 0.068500020970708+Pose[1]},
            {'translation.y': -0.233999999999991+Pose[2]},
            {'rotation.x': Pose[3]},
            {'rotation.y': Pose[4]},
            {'rotation.z': Pose[5]}
        ]
    )

    MyListener_Node = Node(
        package="listener",
        executable="listener_1",
        parameters=[{"components to be calibrated": paramater}]
    )

    ld.add_action(Transform1_Node)
    ld.add_action(MyListener_Node)

    return ld
