from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():

    ld = LaunchDescription()

    Component = 'New_Gripper'        #别这么搞，最后要在terminal输入paramater然后执行，这样要一直启动urdf，会和他有冲突吗

    Increment = [100.0,  # vektor mingzi
            100.0,
            200.0,
            200.0,  # jiaodu  pai?
            520.0,
            120.0]
    

    Transform1_Node = Node(
        package="lab",
        executable="teil_zwei",
        parameters=[
            {'frame_id': 'Camera_Top_View'},
            # mingzi xiangtong you jige a kan rviz   一开始先想到listener这个方法，没注意结构简单，后来就直接用这个了。
            # launch mehr systematisch  broadcaster he listener shi gudingde suoyi bu fei naoxibao
            # gen fuza de haishi broadcaster he listener hao
            {'child_frame_id': Component},
            # 下面这三个位数不一样  gen %f lianxi
            {'translation.x': 0.0795000000000243+Increment[0]},
            {'translation.z': 0.068500020970708+Increment[1]},
            {'translation.y': -0.233999999999991+Increment[2]},
            {'rotation.x': Increment[3]},
            {'rotation.y': Increment[4]},
            {'rotation.z': Increment[5]}
        ]
    )

    MyListener_Node = Node(
        package="listener",
        executable="listener_1",
        parameters=[{"components to be calibrated": Component}]
    )

    ld.add_action(Transform1_Node)
    ld.add_action(MyListener_Node)

    return ld
