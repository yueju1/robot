import rclpy
from rclpy.node import Node
# import xml.etree.ElementTree as ET
import lxml.etree as ET


class Change(Node):
    def __init__(self):
        super().__init__("Change")
        tree = ET.parse(
            '/home/pmlab/pm_ros2_ws/src/match_pm_robot/pm_robot_description/urdf/pm_robot.urdf')
        root = tree.getroot()

        for i in root.iter('joint'):
            if i.attrib['name'] == "Gripper_Joint":
                i.find('origin').set('xyz', '500 100 100')

                tree.write('/home/pmlab/pm_ros2_ws/src/asd1.urdf')

                print(i.find('origin').get('xyz'))
                with open('/home/pmlab/pm_ros2_ws/src/asd1.urdf',
                          'r+', encoding='utf-8') as file:
                    co = file.read()

                    file.seek(0, 0)
                    file.write('<?xml version="1.0" encoding="utf-8"?>\n'+co)
                    print(co.find('<ro'))

                with open('/home/pmlab/pm_ros2_ws/src/asd1.urdf', 'r+') as file1:

                    new = file1.read()

                    file1.seek(new.find('<ro'))
                    file1.write('\n<robot name="pm_robot">')

              # new= file.readlines()
              # print(new)
                # print(co)
                # for line in co:
                # if '<robot' in co:
                #      print(co.find('<ro'))
                #      print(123)
                # file.seek(file.tell())
                # file.read()
                # print(file.tell())
                # file.seek(file.tell())
                # file.write('\n')


def main():
    rclpy.init()
    rclpy.spin(Change())
    rclpy.shutdown()


if __name__ == '__main__':
    main()


""" 
kl=file.readlines()
lie = '    <color rgba="0.792156862745098 0.819607843137255 0.933333333333333 1" />\n'
for line in kl:
   if line==lie: 
      print(lie)  
        
 """
