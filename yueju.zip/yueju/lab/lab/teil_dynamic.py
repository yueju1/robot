import rclpy
from rclpy.node import Node
from tf2_ros import TransformBroadcaster
from geometry_msgs.msg import TransformStamped
from tf2_msgs.msg import TFMessage


class Dynamictransform(Node):
    def __init__(self):
        super().__init__("Camera_Calibration_from_Camera_System")

        self.dy_broadcaster = TransformBroadcaster(self)

        sub = self.create_subscription(TFMessage, "/tf", self.do_transform, 10)

        self.create_timer(1, self.send_transform)

    def do_transform(self, pose):

        self.ts = TransformStamped()

        self.ts.header.stamp = self.get_clock().now().to_msg()

        self.ts.header.frame_id = pose.transforms[0].header.frame_id
        # 这两行改一下！！！用 pose里的。
        self.ts.child_frame_id = pose.transforms[0].child_frame_id

        self.ts.transform.translation.x = pose.transforms[0].transform.translation.x
        self.ts.transform.translation.y = pose.transforms[0].transform.translation.y
        self.ts.transform.translation.z = pose.transforms[0].transform.translation.z

        self.ts.transform.rotation.x = pose.transforms[0].transform.rotation.x
        self.ts.transform.rotation.y = pose.transforms[0].transform.rotation.y
        self.ts.transform.rotation.z = pose.transforms[0].transform.rotation.z
        self.ts.transform.rotation.w = pose.transforms[0].transform.rotation.w

    def send_transform(self):

        self.dy_broadcaster.sendTransform(self.ts)

        self.get_logger().info("hahaha")


def main():
    rclpy.init()
    rclpy.spin(Dynamictransform())
    rclpy.shutdown()


if __name__ == '__main__':
    main()
