import rclpy
from rclpy.node import Node
from tf2_ros.static_transform_broadcaster import StaticTransformBroadcaster
from geometry_msgs.msg import TransformStamped
# yong numpy!!!???
import numpy
import transforms3d

# 用new gripper代替gripper 然后监听，然后可以修改urdf中的gripper jiont
#   并由此修改重心的位置（考虑转动惯量是否需要修改）
#         （gravity off？）
# class Transform1(Node):
#     def __init__(self):
#         super().__init__("relative_position_gripper_to_upper_camera")
#         #下面这个self可以不要把
#         self.broadcaster1=StaticTransformBroadcaster(self)

#         ts1=TransformStamped()

#         ts1.header.stamp=self.get_clock().now().to_msg()
#         ts1.header.frame_id="Z_Axis"
#         ts1.child_frame_id="Gripper"

#         ts1.transform.translation.x=0.0...chao yi xia + numpy
#         ts1.transform.translation.y=
#         ts1.transform.translation.z=

#         ts1.transform.rotation.x=
#         ts1.transform.rotation.y=
#         ts1.transform.rotation.z=
#         ts1.transform.rotation.w=

#         self.broadcaster1.sendTransform(ts1)

# sd = numpy.array([1, 2, 3, 5, 1])
# print(sd[4])
# print(sd.shape)

Pose = transforms3d.quaternions.quat2axangle((1, 123, 546, 234))
print(Pose)


# def main():
#     rclpy.init()
#     rclpy.spin(Transform1())

#     rclpy.shutdown()


# if __name__ == '__main__':
#     main()
